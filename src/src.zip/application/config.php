<?php

return [
    'db_name' => 'app_db',
    'db_host' => '192.168.0.2',
    'db_user' => 'mysql',
    'db_pass' => 'mysql',
];